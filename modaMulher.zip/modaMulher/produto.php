<?php 
$produto = [
    'nome' => 'Camiseta Manga Comprida',
    'preco' => 79.90,
    'imagem' => 'assets/images/produtos/details/foto-carrinho-camiseta-manga-comprida.jpg',
    'categoria' => 'moda-casual'
];
?>

<?php require __DIR__ . "/header.php"; ?>

<main class="produto">
    <div class="container">
        <!-- Navegação -->
        <nav class="mt-4">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="produtos.php">Produtos</a></li>
                <li class="breadcrumb-item active"><?= $produto['nome'] ?></li>
            </ol>
        </nav>

        <div class="row">
            <!-- Imagem do Produto -->
            <div class="col-lg-6 mb-4">
                <img src="<?= $produto['imagem'] ?>" class="img-fluid rounded" alt="<?= $produto['nome'] ?>">
            </div>

            <!-- Informações do Produto -->
            <div class="col-lg-6">
                <h1 class="h2"><?= $produto['nome'] ?></h1>
                
                <!-- Avaliação -->
                <div class="rating mb-3">
                    <?php for($i = 0; $i < 5; $i++): ?>
                        <i class="bi bi-star-fill text-warning"></i>
                    <?php endfor; ?>
                    <span class="ms-2 text-muted">(125 avaliações)</span>
                </div>

                <!-- Preço -->
                <div class="preco-info mb-3">
                    <h3 class="text-primary">R$ <?= number_format($produto['preco'], 2, ',', '.') ?></h3>
                    <p class="text-success">Em até 12x sem juros</p>
                </div>

                <!-- Descrição -->
                <p class="mb-4">Camiseta em algodão com mangas longas, perfeita para looks casuais e confortáveis. Disponível em várias cores.</p>

                <!-- Formulário de Compra -->
                <form action="carrinho.php" method="POST" class="comprar-form">
                    <input type="hidden" name="produto_id" value="1">
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="tamanho" class="form-label">Tamanho</label>
                            <select name="tamanho" id="tamanho" class="form-select" required>
                                <option value="">Selecione</option>
                                <option value="P">P</option>
                                <option value="M">M</option>
                                <option value="G">G</option>
                                <option value="GG">GG</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="quantidade" class="form-label">Quantidade</label>
                            <select name="quantidade" id="quantidade" class="form-select">
                                <?php for($i = 1; $i <= 10; $i++): ?>
                                    <option value="<?= $i ?>"><?= $i ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-success btn-lg w-100 py-3">
                        <i class="bi bi-cart-plus"></i> Adicionar ao Carrinho
                    </button>
                </form>

                <!-- Informações Adicionais -->
                <div class="mt-4">
                    <div class="d-flex gap-4 text-center">
                        <div>
                            <i class="bi bi-truck display-6 text-primary"></i>
                            <p class="small mb-0">Frete Grátis<br>acima de R$ 199</p>
                        </div>
                        <div>
                            <i class="bi bi-arrow-repeat display-6 text-primary"></i>
                            <p class="small mb-0">Troca Grátis<br>em 30 dias</p>
                        </div>
                        <div>
                            <i class="bi bi-shield-check display-6 text-primary"></i>
                            <p class="small mb-0">Compra<br>100% Segura</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Comentários do Facebook -->
        <div class="row mt-5">
            <div class="col-12">
                <h4 class="mb-3">Avaliações dos Clientes</h4>
                <div class="fb-comments" 
                     data-href="https://www.modadamulher.com/produto.php?id=1" 
                     data-width="100%" 
                     data-numposts="5">
                </div>
            </div>
        </div>
    </div>
</main>

<!-- SDK Facebook -->
<div id="fb-root"></div>
<script async defer crossorigin="anonymous" 
        src="https://connect.facebook.net/pt_BR/sdk.js#xfbml=1&version=v17.0"
        nonce="ABC123">
</script>

<?php require __DIR__ . "/footer.php"; ?>