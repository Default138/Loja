const produtos=[
 {id:1,title:'Vestido Floral Aurora',price:129.90,desc:'Vestido leve floral.',img:'assets/prod1.svg'},
 {id:2,title:'Blusa Rosé Breeze',price:79.90,desc:'Blusa em malha macia.',img:'assets/prod2.svg'},
 {id:3,title:'Saia Plissada Dawn',price:99.90,desc:'Saia plissada midi.',img:'assets/prod3.svg'}
];

const grid=document.getElementById('grid');
produtos.forEach(p=>{
  const el=document.createElement('div');
  el.className='card';
  el.innerHTML=`<img src="${p.img}" style="width:100%"/><h3>${p.title}</h3><p>${p.desc}</p><strong>R$ ${p.price}</strong>`;
  grid.appendChild(el);
});
